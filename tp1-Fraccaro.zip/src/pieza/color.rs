#[derive(PartialEq)]
pub enum Color {
    Blanco,
    Negro,
}
