pub enum Tipo {
    Peon,
    Torre,
    Caballo,
    Alfil,
    Dama,
    Rey,
}
